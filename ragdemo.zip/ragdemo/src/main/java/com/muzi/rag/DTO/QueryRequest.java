package com.muzi.rag.DTO;

/**
 * ClassName:QueryRequest
 * Package:S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/5/13 11:35
 * @Version 1.0
 */


public class QueryRequest {
    private String school;
    private String major;
    private String graduationYear;
    private String preferredArea;

    // Getters and Setters
    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getGraduationYear() {
        return graduationYear;
    }

    public void setGraduationYear(String graduationYear) {
        this.graduationYear = graduationYear;
    }

    public String getPreferredArea() {
        return preferredArea;
    }

    public void setPreferredArea(String preferredArea) {
        this.preferredArea = preferredArea;
    }
}