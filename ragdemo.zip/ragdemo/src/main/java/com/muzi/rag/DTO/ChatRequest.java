package com.muzi.rag.DTO;

/**
 * ClassName:ChatRequest
 * Package:S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/6/210:23
 * @Version 1.0
 */


// 内部类：用于封装发送给外部服务的请求体
public class ChatRequest {
    private String question;
    private boolean useContext;

    // Getters and Setters
    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public boolean isUseContext() {
        return useContext;
    }

    public void setUseContext(boolean useContext) {
        this.useContext = useContext;
    }
}
