package com.muzi.rag.controller;

import com.muzi.rag.DTO.LoginRequest;
import com.muzi.rag.entity.User;
import com.muzi.rag.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * ClassName: UserController
 * Package: com.muzi.rag.controller
 * Description:
 *
 * @Author 小雷
 * @Create 2025/5/12 21:52
 * @Version 1.0
 */
@RestController
@RequestMapping("/api")
public class UserController {


    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        System.out.println(user);
        System.out.println("用户注册信息：" + user.getUsername() + " " + user.getPassword() + " " + user.getNickname());
        boolean isRegistered = userService.register(user);
        if (isRegistered) {
            response.put("success", true);
            response.put("message", "注册成功");
            return ResponseEntity.ok(response); // 返回成功信息
        } else {
            response.put("success", false);
            response.put("message", "该账号已被使用，请重新输入");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response); // 返回冲突状态码和错误信息
        }
    }

    @PostMapping("/login")
    public ResponseEntity<User> login(@RequestBody LoginRequest loginRequest) {
        User user = userService.login(loginRequest.getUsername(), loginRequest.getPassword());
        if (user != null) {
            return ResponseEntity.ok(user); // 返回包含 nickname 的用户对象
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }


}