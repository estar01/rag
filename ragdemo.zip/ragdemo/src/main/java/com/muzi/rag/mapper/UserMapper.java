package com.muzi.rag.mapper;

import com.muzi.rag.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * ClassName:UserMapper
 * Package:S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/5/12 21:51
 * @Version 1.0
 */
@Mapper
public interface UserMapper {

    @Select("SELECT * FROM users WHERE username = #{username}")
    User findByUsername(String username);

    @Insert("INSERT INTO users(username, password, nickname) VALUES(#{username}, #{password}, #{nickname})")
    void insert(User user);
}