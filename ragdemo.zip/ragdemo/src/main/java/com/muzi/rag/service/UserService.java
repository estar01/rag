package com.muzi.rag.service;

import com.muzi.rag.mapper.UserMapper;
import com.muzi.rag.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * ClassName: UserService
 * Package: com.muzi.rag.service
 * Description:
 *
 * @Author 小雷
 * @Create 2025/5/12 21:51
 * @Version 1.0
 */
@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public boolean register(User user) {
        // 检查用户名是否已存在
        if (userMapper.findByUsername(user.getUsername()) != null) {
            return false; // 用户名已存在，注册失败
        }

        // 插入新用户
        userMapper.insert(user);
        return true; // 注册成功
    }

    public User login(String username, String password) {
        User user = userMapper.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user; // 登录成功
        }
        System.out.println("用户名或密码错误");
        System.out.println(username + " " + password);
        if (user != null) {
            System.out.println(user.getUsername() + " " + user.getPassword());
        }
        return null; // 登录失败
    }
}