package com.muzi.rag.DTO;

/**
 * ClassName:LoginRequest
 * Package:S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/5/1223:13
 * @Version 1.0
 */
public class LoginRequest {
    private String username;
    private String password;

    // Getters and Setters

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}