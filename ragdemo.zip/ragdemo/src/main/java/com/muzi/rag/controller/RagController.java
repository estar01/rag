package com.muzi.rag.controller;

import com.muzi.rag.DTO.ChatRequest;
import com.muzi.rag.DTO.ChatResponse;
import com.muzi.rag.common.vo.Result;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

/**
 * ClassName: RagController
 * Package: S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/6/2 10:16
 * @Version 1.0
 */
@RestController
public class RagController {

    private final RestTemplate restTemplate = new RestTemplate();

    @GetMapping("/ai/generate")
    public Result generate(@RequestParam(value = "prompt", defaultValue = "你是谁") String prompt) {
        String url = "http://localhost:5000/api/chat";

        // 构造请求体
        ChatRequest chatRequest = new ChatRequest();
        chatRequest.setQuestion(prompt);
        chatRequest.setUseContext(true);

        // 设置请求头
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // 构建请求实体
        HttpEntity<ChatRequest> entity = new HttpEntity<>(chatRequest, headers);

        // 发送 POST 请求
        ResponseEntity<ChatResponse> response = restTemplate.postForEntity(url, entity, ChatResponse.class);

        // 提取 answer 字段
        String answer = response.getBody() != null ? response.getBody().getAnswer() : "暂无回答";

        // 使用正则表达式去除 <think> 和 </think>
        answer = answer.replaceAll("<think>|</think>|\\n", "").trim();

        // 返回结果
        Result result = Result.success();
        result.setData(answer);
        return result;
    }

}