package com.muzi.rag.DTO;

/**
 * ClassName:ChatResponse
 * Package:S{PACKAGE_NAME}
 * Description:
 *
 * @Author 小雷
 * @Create 2025/6/210:28
 * @Version 1.0
 */
public class ChatResponse {
    private String answer;
    private String question;
    private boolean useContext;

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public boolean isUseContext() {
        return useContext;
    }

    public void setUseContext(boolean useContext) {
        this.useContext = useContext;
    }
}
