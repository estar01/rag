package com.muzi.rag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaoyanApplicationTests {

    @Test
    void contextLoads() {
    }

}
